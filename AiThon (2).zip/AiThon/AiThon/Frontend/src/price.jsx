import React from 'react'
import Prices from './components/prices.jsx'
// import LineChart from './components/Linechart.jsx'

const price = () => {
  return (
    <div>
      <Prices/>
      {/* <LineChart/> */}
    </div>
  )
}

export default price
