import React from 'react';
import { useEffect } from 'react';
const LineChart = () => {
    useEffect(() => {
        const script = document.createElement('script');
        script.src = 'https://widgets.coingecko.com/gecko-coin-price-chart-widget.js'; // URL of the script
        script.async = true;
        
        document.body.appendChild(script);
    
        return () => {
          // Cleanup: remove the script when the component unmounts
          document.body.removeChild(script);
        };
      }, []);

      return (
    
<gecko-coin-price-chart-widget locale="en" dark-mode="true" transparent-background="true" outlined="true" coin-id={coin} initial-currency="usd"></gecko-coin-price-chart-widget>    
    );
};

export default LineChart;
