import React from 'react';
import bitcoinImage from '../assets/bitcoin.gif'
import heroimg from "../assets/herobg.jpg"
import Price from "../components/prices.jsx"
import { Link } from 'react-router-dom';

const HeroSec = () => {
  return (
    <section
      className="relative bg-cover bg-center h-[90vh] flex flex-col justify-center items-center text-center -z-20"
      style={{ backgroundImage:`url(${heroimg})`} }    >
        <img
        src={bitcoinImage}
        alt="Bitcoin"
        className="w-24 h-24 md:w-32 md:h-32 hover:animate-spin transition-transform duration-500 ease-in-out"
      />
      <h1 className="text-white text-3xl md:text-7xl font-bold mb-4">
        Track Cryptocurrency in Real-Time
      </h1>
      <p className="text-white text-lg md:text-xl mb-8">
        Stay updated with the latest trends and prices of your favorite cryptocurrencies.
      </p>
    </section>
  );
};



export default HeroSec;
