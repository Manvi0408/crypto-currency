import React, { useEffect, useState } from 'react';

const API_URL = 'https://api.cryptorank.io/v1/currencies?api_key=eb3bd1ffb5026ccea1a42624584ea96e7fe13c1eaba903ccc8c13c560b6a';

const CryptoTable = () => {
  const [cryptoData, setCryptoData] = useState([]);

  useEffect(() => {
    async function fetchData() {
      try {
        const response = await fetch(API_URL);
        const jsonData = await response.json();
        const mappedData = jsonData.data.map((crypto) => {
          const {
            id,
            name,
            symbol,
            values: {
              USD: { price, marketCap, percentChange24h }
            }
          } = crypto;

          return {
            id,
            name,
            symbol,
            price,
            marketCap,
            change: percentChange24h
          };
        });
        setCryptoData(mappedData);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    }

    fetchData();
  }, []);

  return (
    <div className='p-4 md:p-20 overflow-x-scroll'>
    <h1 className="text-3xl font-bold mb-4 flex justify-center pb-5 md:text-6xl">Crypto prices</h1>
    <table className="min-w-full  border border-gray-200">
      <thead>
        <tr className='text-3xl text-orange-500'>
          <th className="px-4 md:text-3xl lg:text-left  py-2">Name</th>
          <th className="px-4 md:text-3xl lg:text-left py-2">Price (USD)</th>
          <th className="px-4 md:text-3xl lg:text-left py-2">Market Cap (USD)</th>
          <th className="px-4 md:text-3xl lg:text-left py-2">24h Change</th>
        </tr>
      </thead>
      <tbody>
        {cryptoData.map((crypto) => (
          <tr key={crypto.symbol} className="border-b border-gray-200">
            <td className="px-4 py-3 flex items-center">
              <span className="w-6 h-6 rounded-full bg-gray-300 mr-2">
                <img src={`https://assets.coincap.io/assets/icons/${crypto.symbol.toLowerCase()}@2x.png`}/>
              </span>
              <div>
                <span className="font-medium">{crypto.name}</span>
                <span className="text-gray-500 text-xs ml-2">{crypto.symbol}</span>
              </div>
            </td>
            <td className="px-4 py-3">
              <span className="font-medium">
                ${crypto.price.toFixed(2)}
              </span>
            </td>
            <td className="px-4 py-3">
              <span className="font-medium">
                ${crypto.marketCap.toLocaleString()}
              </span>
            </td>
            <td
              className={`px-4 py-3 text-center text-left ${
                crypto.change > 0 ? 'text-green-500' : 'text-red-500'
              }`}
            >
              {crypto.change > 0 ? '+' : ''}
              {crypto.change.toFixed(2)}%
            </td>
          </tr>
        ))}
      </tbody>
    </table>
    </div>
  );
};

export default CryptoTable;
