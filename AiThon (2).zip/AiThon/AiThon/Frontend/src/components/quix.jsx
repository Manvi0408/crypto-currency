import React, { useState } from 'react';

const quizQuestions = [
    
        // Beginner
        { question: "What is Bitcoin?", options: ["A type of traditional currency", "A digital currency", "A new programming language", "A cryptocurrency exchange"], correctAnswer: "A digital currency" },
        { question: "Who is the creator of Bitcoin?", options: ["Vitalik Buterin", "Charlie Lee", "Satoshi Nakamoto", "Elon Musk"], correctAnswer: "Satoshi Nakamoto" },
        { question: "What is the primary purpose of blockchain technology?", options: ["To store personal data", "To facilitate peer-to-peer transactions securely", "To create video games", "To monitor internet traffic"], correctAnswer: "To facilitate peer-to-peer transactions securely" },
        { question: "Which of the following is a popular altcoin?", options: ["Dogecoin", "Bitcoin", "Litecoin", "Both a and c"], correctAnswer: "Both a and c" },
        { question: "What is a ‘wallet’ in cryptocurrency terms?", options: ["A physical container for storing cash", "A digital tool for managing cryptocurrency assets", "A bank account for crypto", "A type of trading software"], correctAnswer: "A digital tool for managing cryptocurrency assets" },
      
        // Intermediate
        { question: "What is Ethereum primarily used for?", options: ["As a digital currency like Bitcoin", "As a platform for decentralized applications (dApps) and smart contracts", "As a type of hardware wallet", "As a cryptocurrency exchange"], correctAnswer: "As a platform for decentralized applications (dApps) and smart contracts" },
        { question: "What does “mining” refer to in the context of cryptocurrency?", options: ["Extracting digital gold from the internet", "The process of validating transactions and adding them to the blockchain", "Creating new cryptocurrency coins out of thin air", "Selling cryptocurrencies for profit"], correctAnswer: "The process of validating transactions and adding them to the blockchain" },
        { question: "Which cryptocurrency is known as “digital gold”?", options: ["Litecoin", "Bitcoin", "Ripple", "Cardano"], correctAnswer: "Bitcoin" },
        { question: "What does “FOMO” stand for in the context of investing in cryptocurrencies?", options: ["Fear of Missing Out", "Fear of Market Orders", "Future Operations Market Optimization", "Federal Organization of Market Operations"], correctAnswer: "Fear of Missing Out" },
        { question: "Which of the following is NOT a consensus mechanism used in cryptocurrencies?", options: ["Proof of Work", "Proof of Stake", "Proof of Burn", "Proof of Purchase"], correctAnswer: "Proof of Purchase" },
      
        // Advanced
        { question: "What is a ‘smart contract’?", options: ["A legal document signed digitally", "A self-executing contract with the terms directly written into code", "A type of cryptocurrency wallet", "A contract for hiring smart people"], correctAnswer: "A self-executing contract with the terms directly written into code" },
        { question: "What is the primary function of a Decentralized Autonomous Organization (DAO)?", options: ["To centralize decision-making power", "To manage traditional corporate resources", "To operate as a decentralized entity governed by smart contracts and community voting", "To create centralized crypto exchanges"], correctAnswer: "To operate as a decentralized entity governed by smart contracts and community voting" },
        { question: "Which cryptocurrency was designed to be an improvement over Bitcoin by offering faster transaction times and lower fees?", options: ["Monero", "Bitcoin Cash", "Ethereum Classic", "Dogecoin"], correctAnswer: "Bitcoin Cash" },
        { question: "What does ‘DeFi’ stand for?", options: ["Digital Finance", "Decentralized Finance", "Dynamic Financial Instruments", "Direct Funding Investment"], correctAnswer: "Decentralized Finance" },
        { question: "In cryptocurrency, what is a ‘hard fork’?", options: ["A new type of mining equipment", "A change to a cryptocurrency’s protocol that is not backward-compatible", "A method to increase transaction speed", "A software used for trading"], correctAnswer: "A change to a cryptocurrency’s protocol that is not backward-compatible" }
    
      

];

const Quiz = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const totalQuestions = quizQuestions.length;
  const [result, setResult] = useState('');

  const loadQuestion = () => {
    return quizQuestions[currentQuestionIndex];
  };

  const handleAnswer = (selectedOption) => {
    const correctAnswer = quizQuestions[currentQuestionIndex].correctAnswer;
    if (selectedOption === correctAnswer) {
      setScore(score + 1);
    }
    const nextQuestionIndex = currentQuestionIndex + 1;
    if (nextQuestionIndex < totalQuestions) {
      setCurrentQuestionIndex(nextQuestionIndex);
    } else {
      showResult();
    }
  };

  const showResult = () => {
    if (score > totalQuestions / 2) {
      setResult(`You win! Your score: ${score}/${totalQuestions}`);
    } else {
      setResult(`You lose. Your score: ${score}/${totalQuestions}`);
    }
  };

  const question = loadQuestion();

  return (
    <div className="min-h-screen text-white flex flex-col items-center justify-center p-4">
      {result ? (
        <div className="text-3xl font-bold">{result}</div>
      ) : (
        <>
          <div className="text-4xl font-bold mb-8">
            {question.question}
          </div>
          <div className="flex flex-row space-x-4 mb-8">
            {question.options.map((option, index) => (
              <button
                key={index}
                className=" text-white py-3 px-6 border-b-2 border-b-orange-500 transition font-semibold text-lg"
                onClick={() => handleAnswer(option)}
              >
                {option}
              </button>
            ))}
          </div>
          <button
            className="border-2 border-orange-500 text-white py-2 px-6 rounded-md hover:bg-orange-400 transition font-semibold text-lg"
            onClick={() => handleAnswer(null)}
          >
            Next
          </button>
        </>
      )}
    </div>
  );
};

export default Quiz;
