import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleNavbar = () => {
    setIsOpen(!isOpen);
  };

  return (
    <nav className="bg-slate-600 bg-opacity-10 backdrop-blur-3xl p-4 z-40">
      <div className="container mx-auto flex justify-between items-center">
        <div className="text-orange-500 text-2xl font-bold">Brand</div>
        <div className="md:hidden flex-grow flex justify-end">
          <button onClick={toggleNavbar}>
            {isOpen ? <X className="w-6 h-6 hover:text-orange-500" /> : <Menu className="w-6 h-6 text-orange-500" />}
          </button>
        </div>
        <div className="relative md:static">
          <div
            className={`fixed inset-0 z-40 transition-transform transform bg-white bg-opacity-10 backdrop-blur-md md:bg-transparent md:backdrop-blur-none md:static md:inset-auto md:flex md:items-center md:justify-end ${
              isOpen ? 'translate-x-0 h-[100vh] w-[80vw] border-r-2 border-orange-500' : '-translate-x-full md:translate-x-0'
            }`}
          >
            <div className="flex flex-col md:flex-row md:gap-4 px-4 md:mt-0 mt-14 md:p-0 ">
              <Link className="hover:text-orange-500 text-lg p-2 hover:underline" to="/">Home</Link>
              <Link className="hover:text-orange-500 text-lg p-2 hover:underline" to="/price">Prices</Link>
              <Link className="hover:text-orange-500 text-lg p-2 hover:underline" to="/services">History</Link>
              {/* <Link className="hover:text-orange-500 text-lg p-2 hover:underline" to="/contact"></Link> */}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
