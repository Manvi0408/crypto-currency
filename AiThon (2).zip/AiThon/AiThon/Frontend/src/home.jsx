import React from 'react'
import HeroSec from './components/hero.jsx'
import Quiz from './components/quix.jsx'
const home = () => {
  return (
    <div>
       <HeroSec/>
       <Quiz/>
       
    </div>
  )
}

export default home
