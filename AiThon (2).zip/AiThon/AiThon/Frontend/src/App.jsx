import React from 'react'
import Home from './home.jsx'
import Navbar from './components/navbar.jsx'
import { navData } from '../context.jsx'
import { HashRouter as Router, 
  Routes,
  Route,
  Link } from 'react-router-dom'
import Price from './price.jsx'

const App = () => {
  return (
    <>
     <Router>
     <Navbar nav={navData}/>
      <Routes>

          <Route path="/" element={<Home/>}/>
            
          
          <Route path="/price" element={<Price/>}/>
            
          
          {/* <Route path="/Service" element={<Service/>}/>
            
          <Route path="/Contact" element={<Contact/>}/> */}
          {/* <Route path = "*" element={<Error404/>}/> */}
      </Routes>
   </Router> 
    </>
  )
}

export default App
