export const navData = {
    sections : [
    { label: "Home", href: "/" },
    { label: "About", href: "/Service" },
    { label: "Projects", href: "/Aboutus" },
    { label: "Contact", href: "/Contact" }
  ]
  };